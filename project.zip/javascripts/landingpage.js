/*$( window ).resize(function() {
  location.reload();
});
*/




$(document).ready(function(){



});
